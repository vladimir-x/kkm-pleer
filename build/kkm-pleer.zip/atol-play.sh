java -Djava.library.path=lib/native/linux-64 -jar kkm-pleer-1.0-SNAPSHOT.jar \
        -f music/some.txt -v -30 \
        -kkm atol10 -ip 172.0.0.1:5555
