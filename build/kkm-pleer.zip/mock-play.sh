cd $(dirname $0);

java -jar kkm-pleer-1.0-SNAPSHOT.jar -f music/some.txt
